<template>
  <div id="app">

      <a href="#/">主页   </a>
      <a href="#/user">用户管理   </a>
      <a href="#/stu">学生管理    </a>

      <a href="#/rains">雨滴实验              </a>

      <a href="#/test">测试</a>



    
    <!-- <img alt="Vue logo" src="./assets/logo.png"> -->
    <!-- <HelloWorld msg="你好？？？？？？Welcome to Your Vue.js App"/> -->
    <router-view></router-view>
     <!-- <router-view/> -->
  </div>
</template>

<script>
// import HelloWorld from './components/HelloWorld.vue'

// export default {
//   name: 'App',
//   components: {
//     HelloWorld
//   }
// }
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;

  align-content: center;
  align-items: center;
align-self: center;
}
</style>
