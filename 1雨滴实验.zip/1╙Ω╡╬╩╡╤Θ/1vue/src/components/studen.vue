<template>
  <h1>这是学生</h1>
</template>

<script>
export default {

    name:'stu'

}
</script>

<style>

</style>