<template>
  <div id="userid">

   <h1>这是用户</h1>

  <table border="1" style="margin:auto">

    <tr>
      <td>编号</td> <td>姓名</td>   <td>年龄</td>   <td>生日</td>   <td>操作</td> 
    </tr>
    <tr v-for="(user,index) in users" v-bind:key="index">
       <!-- <td>2020</td> <td>周星驰</td>   <td>30</td>   <td>1997-07-08</td>   <td><a href="#">删除</a>  <a href="#">修改</a></td>  -->
        <td>{{user.id}}</td> <td>{{user.name}}</td>   <td>{{user.age}}</td>   <td>{{user.bir}}</td>  
         <td><a href="javascript:;" @click="delrow(user.id)">删除</a>  <a :href="'#/user/updata?id='+user.id">修改</a></td>  
         <!-- href="javascript:;" 阻住监听事件 -->
    </tr>
    <tr><a href="#/user/user_chiladd">添加</a><br></tr>
    
    
  </table>
  
<router-view></router-view>


  </div>

</template>

<script>
export default {
    name:'user',
    
    components:{},

     data(){
      return{

          users:[]

      }

    },


    methods:{
         findall(){
            this.$http.get('http://rap2.taobao.org:38080/app/mock/259088/user/findall?page=1&rows=5').then((res)=>{
        // console.log(res.data);
            console.log(res.data.reselts);
            console.log("这是怎么啦？正在从后台加载数据"+res.data.reselts);

            this.users=res.data.reselts;    
            });
              },

          delrow(id){
            console.log('id的值为：'+id);
            this.$http.get('http://rap2.taobao.org:38080/app/mock/259088/user/delete?id='+id).then((res)=>{
              console.log(res);
              if(res.data.success){
                alert(res.data.msg+"\n点击刷新数据");
                console.log('可以偶，删除掉了');
                this.findall();

              }
            });

          }
    },



    created(){
            

        this.findall();
      },


      // 监听,当路由发生变化的时候执行
      watch: {
        $route: {
          handler: function(val){
            console.log('监听路由变化');
            console.log(val);
            if(val.path=='/user'){
              this.findall();
            }
          },
          // 深度观察监听
          deep: true
        }
      },


      

    // // 监听,当路由发生变化的时候执行
    // watch:{
    //   $route(to){
    //      console.log('监听路由变化');
    //     console.log(to.path);
    //   }
    // },




      

}
</script>

<style>



</style>