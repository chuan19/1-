<template>
  <div id="app">
      <table border="1" style="margin:auto">
         <tr> <td>id值</td>  <td>yid值</td>  <td>年份</td>  <td>月份</td>  <td>日期</td>  <td>时间字符</td>  <td>时间数组</td>  <td>总数</td> </tr>

        <tr v-for="(rain,index) in rains" v-bind:key="index"> 
        <td>{{rain.id}}</td>  <td>{{rain.yid}}</td>  <td>{{rain.year}}</td>  <td>{{rain.month}}</td>  <td>{{rain.data}}</td>  <td>{{rain.time}}</td>  <td>{{rain.times}}</td>  <td>{{rain.total}}</td>
        </tr>

      </table>
   <h1>{{this.rains[1].year}}-{{this.rains[1].month}}-{{this.rains[1].data}}下雨时间</h1>
   <div id="main" style="width: 600px;height:400px;margin:auto">div应用1</div>
        <!-- <br>
      <p v-for="(user,i) in list2" v-bind:key="user.id">id是{{user.id}}---名字是{{user.name}}---索引是{{i}}</p> -->

  </div>
</template>

<script>
export default {
    name:'rains',
    methods:{

            select(){//http://rap2.taobao.org:38080/app/mock/259088/rains    http://localhost:8082/test
                    this.$http.get(' http://localhost:8082/test').then((res)=>{
                    
                        console.log(res.data.rains);
                        //  this.rains[1]=res.data;
                        // this.rains.push(res.data.rains);
                        this.rains=res.data.rains;
                        console.log('取出的雨点：'+res.data.rains[1].time);
                        console.log('数组：'+this.rains[1].time);
                        //  for (var i in this.rai){
                        //      console.log("历遍："+i.love);

                        //  }
                     });
                },


                echar(goodtime){
    
                        var echarts = require('echarts'); 
                        
                    // 基于准备好的dom，初始化echarts实例
                var myChart = echarts.init(document.getElementById('main'));
        
                console.log("方法内的时间："+this.times);

                for (var i=0;i<goodtime.length;i++){
                    console.log(i+1);
                    this.totals.push(i+1);

                }
                console.log("总数为："+this.totals);

                // goodtime=this.test3
                var option = {
                    xAxis: {
                        type: 'category',
                        data: goodtime
                    },
                    yAxis: {
                        type: 'value'
                    },
                    series: [{
                        data:this.totals,
                        type: 'line',
                        smooth: true
                    }]
                };



                // 使用刚指定的配置项和数据显示图表。
                myChart.setOption(option);

        },


         getdata(){

                this.$http.get('http://localhost:8082/test').then((res)=>{
                    // console.log("测试的结果：");
                    // console.log(res.data);


                        console.log("雨点数据");
                        console.log(res.data.rains);
                        //  this.rains[1]=res.data;
                        // this.rains.push(res.data.rains);
                        this.rains=res.data.rains;
                        console.log('取出的雨点：'+res.data.rains[1].times);
                        console.log('数组：'+this.rains[1].times);
                        this.times=this.rains[1].times;
                        console.log(this.times);
                        console.log('这时的test：'+this.test);
                        this.echar(this.times);
                    
                    });

                }
    },
    data(){
        return{
            rains:[],

            times:[],
            totals:[]
            //  rai:[{love:'love',nice:'good study'},{}],
            //  list2:[{ id:1, name:'小白' },{ id:2, name:'小黑' },{ id:3, name:'小黄' }],
        }
    },

    created(){
        this.select();

    },

    mounted(){
        this.getdata();
    }
   
   
   


}
</script>

<style>

</style>