<template>
  <div>

     <h1>添加用户信息</h1>

     <form>
           用户名:<input type="text" v-model="user.name"><br>
           年龄  ：<input type="text" v-model="user.age"><br>
           生日  ：<input type="text" v-model="user.bir"><br>
           <input type="button" value="添加用户信息" @click="save_user">

     </form>



  </div>
</template>

<script>
export default {
    name:'useradd',
    methods:{
        save_user(){
            console.log(this.user);
            this.$http.post('http://rap2.taobao.org:38080/app/mock/259088/user/add',this.user).then((res)=>{
                console.log(res.data);
                 if(res.data.success){
                    this.$router.push('/user');//切换路由，但不能更新查询所有
                }
                
                });
               
            
            }
    },
    data(){return{
        user:{}
    }}

}
</script>

<style>

</style>