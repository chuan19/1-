<template>

 

  <div id="app">
      <h1>测试用的vue</h1>
   <div id="main" style="width: 600px;height:400px;">div应用1</div>
   <div id="myChart" :style="{width: '300px', height: '300px'}"></div>
  </div>

  

</template>

<script>
 
 
 



export default {
    name:'test',
    methods:{


        echar(goodtime){
    
                        var echarts = require('echarts'); 
                        
                    // 基于准备好的dom，初始化echarts实例
                var myChart = echarts.init(document.getElementById('main'));
        
                console.log("方法内的时间："+this.times);

                for (var i=0;i<goodtime.length;i++){
                    console.log(i+1);
                    this.totals.push(i+1);

                }
                console.log("总数为："+this.totals);

                // goodtime=this.test3
                var option = {
                    xAxis: {
                        type: 'category',
                        data: goodtime
                    },
                    yAxis: {
                        type: 'value'
                    },
                    series: [{
                        data:this.totals,
                        type: 'line',
                        smooth: true
                    }]
                };



                // 使用刚指定的配置项和数据显示图表。
                myChart.setOption(option);

        },


         getdata(){

                this.$http.get('http://localhost:8082/test').then((res)=>{
                    // console.log("测试的结果：");
                    // console.log(res.data);


                        console.log("雨点数据");
                        console.log(res.data.rains);
                        //  this.rains[1]=res.data;
                        // this.rains.push(res.data.rains);
                        this.rains=res.data.rains;
                        console.log('取出的雨点：'+res.data.rains[1].times);
                        console.log('数组：'+this.rains[1].times);
                        this.times=this.rains[1].times;
                        console.log(this.times);
                        console.log('这时的test：'+this.test);
                        this.echar(this.times);
                    
                    });

                }

                
        
    },
    data(){
        return{
            test:['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            test2:['16-00-12','16-00-28','16-00-39','16-00-43'],
            test3:[ "16-00-12", "16-00-28", "16-00-39", "16-00-43" ],	

            data1:[1,2,3,4,5],
            data2:[820, 932, 901, 934, 1290, 1330, 1320],

            rains:[],
            times:[],
            totals:[]

        }
    },

    mounted(){
       
         
        // this.echar();
        this.getdata();

    },
    created(){
        // this.$http.get('http://localhost:8082/test').then((res)=>{
        //     // console.log("测试的结果：");
        //     // console.log(res.data);


        //           console.log("雨点数据");
        //          console.log(res.data.rains);
        //         //  this.rains[1]=res.data;
        //         // this.rains.push(res.data.rains);
        //         this.rains=res.data.rains;
        //          console.log('取出的雨点：'+res.data.rains[1].times);
        //          console.log('数组：'+this.rains[1].times);
        //          this.times=this.rains[1].times;
        //         console.log(this.times);
        //     console.log('这时的test：'+this.test);
            
        //     });
    }
}



</script>

<style>

#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;

  align-content: center;
  align-items: center;
align-self: center;
}

</style>