<template>
  <div>
      <h1>修改用户信息</h1>
      <from>
            用户名:<input type="text" v-model="user.name"><br>
           年龄  ：<input type="text" v-model="user.age"><br>
           生日  ：<input type="text" v-model="user.bir"><br>
           <input type="button" value="修改用户信息" @click="updata_user">

      </from>

  </div>
</template>

<script>
export default {
    name:'updata',
    data(){
        return{
           user:{id:'',}
        };
    },
    methods:{
        findone(){
            this.$http.get('http://rap2.taobao.org:38080/app/mock/259088/user/updatafind?id='+this.user.id).then((res)=>{
              
                console.log('修改信息：'+res);
                this.user=res.data;

            });
        },

        updata_user(){
            console.log(this.user);
            this.$http.post('http://rap2.taobao.org:38080/app/mock/259088/user/updata',this.user).then((res)=>{
                console.log('接受到的数据：'+res.data.success);
                if(res.data.success){
                    this.$router.push('/user');

                }

            });

        }
    },
    created(){
        console.log("修改的id："+this.$route.query.id);
        this.user.id=this.$route.query.id;
        this.findone();
    }


}
</script>

<style>

</style>