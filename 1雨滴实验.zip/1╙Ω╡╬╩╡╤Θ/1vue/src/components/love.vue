<template>

 <div id="idlove">
      <h1>欢迎{{msg}}来到主页</h1>
            
 </div>

</template>

<script>
export default {
    name:"love1",
    data(){
        return{
            msg:"喜剧之王周星驰"
        }
       
    }

}
</script>

<style>
#idlove {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>



