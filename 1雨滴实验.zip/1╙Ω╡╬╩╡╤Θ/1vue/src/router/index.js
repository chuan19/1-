import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'

import love1 from '@/components/love'
import stu from '../components/studen'
import user from '../components/user'
import useradd from '../components/useradd'
import updata from '../components/userupdata'

import rains from '../components/rains'
import test from '../components/test'
Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/love',
      name: 'HelloWorld',
      component: HelloWorld
    },

    {
      path: '/',
      component: love1
    },
    {
      path: '/stu',
      component: stu
    },
    {
      path: '/user',
      component: user,
      children:[{path:'user_chiladd',component:useradd},
                {path:'updata',component:updata}
    ]
    },

    // {
    //   path: '/useradd',
    //   component: useradd
    // }


    // {
    //   path:'/updata',component:updata
    // }

    {path:'/rains',component:rains},
    {path:'/test',component:test}


  ]
})
